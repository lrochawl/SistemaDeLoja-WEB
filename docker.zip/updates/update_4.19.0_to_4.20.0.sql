-- Alterando tabela lancamentos
ALTER TABLE lancamentos ADD observacoes TEXT DEFAULT NULL NULL;
